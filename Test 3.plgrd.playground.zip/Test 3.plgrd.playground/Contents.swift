//1 - Consider the follow code snippet.
var indices: [String] = []
for i in 3..<9 {
indices.append(String(i))
}
print(indices)
[3, 4, 5, 6, 7, 8]
["3", "4", "5", "6", "7", "8"]
//What will the final line print to the console?


//2 - In what order would these items be printed?
let animals = ["Dog", "Cat", "Panda", "Giraffe"]
    //          0       1       2       3
let initialArray = 1
let finalArray = animals.count - 1 // 3

for animal in animals[1...animals.count - 1] {
print(animal)
}

//a) ”Giraffe", "Panda", "Cat", "Dog"
//b) It could be any order, arrays are not ordered
//c) ”Cat", "Panda", "Giraffe" x
//d) This code will result in an error
//e) ”Panda", "Cat", "Dog"





