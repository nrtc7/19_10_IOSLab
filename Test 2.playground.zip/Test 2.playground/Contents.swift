//let fruits = ["banana", "maçã", "laranja", "goiaba"]
//              0          1        2          3
//for fruit in fruits {
//    fruit.uppercased()
////    if fruit.starts(with: "b") {
////        print("Essa fruta começa com B: \(fruit)")
////    } else {
////        print("Essa fruta NÃO começa com B: \(fruit)")
////    }
//}
//
////Criar um array de Nomes de Pessoas, no minimo 5 itens, adicionar um elemento a ele.
////Iterar o array e transformar todos itens em maiusculo
//
//var names = ["Paulo", "Bill Portões", "Steve Trabalhost", "John Doe", "Jane Doe"]
//
//names.append("Mario")
//var upperCasedNames: [String] = []
//for name in names {
//    upperCasedNames.append(name.uppercased())
//    print(name.uppercased())
//}

var numbers: [Float] = []
for index in 0...Int.random(in: 4...9) {
    numbers.append(Float.random(in: 0...20))
}
print(numbers)

var sum: Float = 0
for number in numbers {
    sum += number
}
print(sum)
print(numbers.count)
print(sum/Float(numbers.count))

for number in numbers {
    print(number)
}

for index in numbers.indices {
    print(numbers[index])
}

for (index, number) in numbers.enumerated() {
    print(number)
}

//print(numbers.reduce(0) { $0 + $1 } / Float(numbers.count))
// Tirar a média de valores

//let numbers: [Float] = [13, 2, 8, 4, 52, 26]
